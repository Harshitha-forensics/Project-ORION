#!/bin/bash

CASE="$1"
SUBJECT="$2"

EXAMINER="Harshitha"
LOG="/var/log/nginx/access.log"
DOWNLOAD_DIR="/home/harshitha/.local/share/torbrowser/tbb/x86_64/tor-browser/Browser/Downloads"
WEBROOT="/var/www/html/orion-case"
EVIDENCE_DIR="$HOME/ORION-CASE-EVIDENCE"

if [ -z "$CASE" ] || [ -z "$SUBJECT" ]; then
    echo
    echo "ORION INVESTIGATOR"
    echo
    echo "Usage:"
    echo "  ~/orion_investigator.sh ORION-001 VISITOR-01"
    echo
    exit 1
fi

BASELINE="$HOME/${CASE}_baseline.txt"

if [ ! -f "$BASELINE" ]; then
    echo
    echo "ERROR: Case baseline not found:"
    echo "$BASELINE"
    echo
    echo "Create the baseline before the visitor starts."
    exit 1
fi

mkdir -p "$WEBROOT"
mkdir -p "$EVIDENCE_DIR"

START_LINE=$(awk '{print $1}' "$BASELINE")

# Preserve only this case's new server activity.
sudo awk -v n="$START_LINE" 'NR > n' "$LOG" \
    > "/tmp/${CASE}_activity.log"

CASELOG="/tmp/${CASE}_activity.log"

# ------------------------------------------------------------
# SEARCH QUERY
# ------------------------------------------------------------

SEARCH_LINE=$(grep -m 1 'GET /search.html?q=' "$CASELOG")

QUERY="Not directly recorded"
SEARCH_TIME="Not recorded"

if [ -n "$SEARCH_LINE" ]; then

    QUERY=$(echo "$SEARCH_LINE" |
        sed -n 's/.*GET \/search\.html?q=\([^& ]*\).*/\1/p')

    # Decode the most common URL encodings used by our controlled topics.
    QUERY=$(printf '%s' "$QUERY" | sed \
        -e 's/%20/ /g' \
        -e 's/%2F/\//g' \
        -e 's/%3A/:/g')

    SEARCH_TIME=$(echo "$SEARCH_LINE" |
        awk '{print $4}' |
        sed 's/\[//' |
        cut -d: -f2-4)

fi

# ------------------------------------------------------------
# RECORD ACCESSED
# ------------------------------------------------------------

case "$QUERY" in
    flowers)
        RECORD="Flowers Research Record"
        ;;
    mountain)
        RECORD="Mountain Research Record"
        ;;
    football)
        RECORD="Football Research Record"
        ;;
    space)
        RECORD="Space Research Record"
        ;;
    pizza)
        RECORD="Pizza Research Record"
        ;;
    technology)
        RECORD="Technology Research Record"
        ;;
    music)
        RECORD="Music Research Record"
        ;;
    photography)
        RECORD="Photography Research Record"
        ;;
    travel)
        RECORD="Travel Research Record"
        ;;
    ai)
        RECORD="AI Research Record"
        ;;
    "")
        RECORD="Not recovered"
        ;;
    *)
        RECORD="$QUERY Research Record"
        ;;
esac

# DOWNLOAD
# ------------------------------------------------------------

DOWNLOAD_LINE=$(grep -m 1 'GET /orion-downloads/' "$CASELOG")

DOWNLOAD="Not recovered"
DOWNLOAD_TIME="Not recorded"

if [ -n "$DOWNLOAD_LINE" ]; then

    DOWNLOAD=$(echo "$DOWNLOAD_LINE" |
        sed -n 's/.*GET \/orion-downloads\/\([^? ]*\).*/\1/p')

    DOWNLOAD_TIME=$(echo "$DOWNLOAD_LINE" |
        awk '{print $4}' |
        sed 's/\[//' |
        cut -d: -f2-4)

fi

# ------------------------------------------------------------
# LOCAL FILE STATUS
# ------------------------------------------------------------

LOCAL_STATUS="Not applicable"

if [ "$DOWNLOAD" != "Not recovered" ]; then

    if [ -f "$DOWNLOAD_DIR/$DOWNLOAD" ]; then
        LOCAL_STATUS="Present"
    else
        LOCAL_STATUS="Removed"
    fi

fi

# ------------------------------------------------------------
# SURVIVING EVIDENCE
# ------------------------------------------------------------

if [ -s "$CASELOG" ]; then
    SURVIVING="ORION server log"
else
    SURVIVING="No surviving ORION log activity"
fi

# ------------------------------------------------------------
# PRESERVE CASE EVIDENCE
# ------------------------------------------------------------

cp "$CASELOG" \
   "$EVIDENCE_DIR/${CASE}_ORION_server_log.txt"

HASH=$(sha256sum \
    "$EVIDENCE_DIR/${CASE}_ORION_server_log.txt" |
    awk '{print $1}')

# ------------------------------------------------------------
# SAVE CASE DATA
# ------------------------------------------------------------

cat > "$WEBROOT/${CASE}.json" <<JSON
{
  "case_id": "$CASE",
  "subject": "$SUBJECT",
  "searched": "$QUERY",
  "time": "$SEARCH_TIME",
  "accessed": "$RECORD",
  "downloaded": "$DOWNLOAD",
  "local_file": "$LOCAL_STATUS",
  "surviving_evidence": "$SURVIVING",
  "examiner": "$EXAMINER",
  "conclusion": "Activity reconstructed",
  "evidence_hash": "$HASH"
}
JSON

# ------------------------------------------------------------
# VISITOR-FACING ORION RESULT
# ------------------------------------------------------------

cat > "$WEBROOT/index.html" <<HTML
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>ORION // Investigation Result</title>

<link rel="stylesheet" href="/orion.css">

<style>

.result-wrapper {
    max-width:900px;
    margin:50px auto;
}

.result-card {
    background:#0D1320;
    border:1px solid #334155;
    border-radius:14px;
    padding:40px;
    box-shadow:0 20px 60px rgba(0,0,0,.35);
}

.result-header {
    text-align:center;
    padding-bottom:25px;
    border-bottom:1px solid #263449;
    margin-bottom:10px;
}

.result-header h1 {
    margin:8px 0;
    color:#E5E7EB;
}

.result-header p {
    color:#94A3B8;
}

.result-row {
    display:grid;
    grid-template-columns:230px 1fr;
    gap:20px;
    padding:19px 0;
    border-bottom:1px solid #1E293B;
}

.result-label {
    color:#00D9FF;
    font-weight:700;
    letter-spacing:1px;
}

.result-value {
    color:#E5E7EB;
    font-weight:500;
}

.conclusion {
    margin-top:30px;
    padding:22px;
    border:1px solid #22C55E;
    border-radius:10px;
    color:#22C55E;
    font-size:20px;
    font-weight:700;
    text-align:center;
}

.forensic-note {
    margin-top:20px;
    padding:15px;
    color:#94A3B8;
    font-size:13px;
    line-height:1.6;
    border-left:3px solid #00D9FF;
}

@media(max-width:650px) {

    .result-card {
        padding:22px;
    }

    .result-row {
        grid-template-columns:1fr;
        gap:5px;
    }

}

</style>

</head>

<body>

<div class="site-shell">

<header class="topbar">

<div class="brand">

<img src="/orion-assets/orion-logo.svg" alt="ORION">

<span>ORION // DIGITAL FORENSICS</span>

</div>

<div class="status">

<span class="dot"></span>

INVESTIGATION COMPLETE

</div>

</header>


<main class="page-wrap">


<div class="result-wrapper">

<div class="result-card">


<div class="result-header">

<div class="eyebrow">

FORENSIC RECONSTRUCTION

</div>

<h1>CASE $CASE</h1>

<p>

SUBJECT: $SUBJECT

&nbsp;&nbsp;|&nbsp;&nbsp;

EXAMINER: $EXAMINER

</p>

</div>


<div class="result-row">

<div class="result-label">

SEARCHED

</div>

<div class="result-value">

$QUERY

</div>

</div>


<div class="result-row">

<div class="result-label">

TIME

</div>

<div class="result-value">

$SEARCH_TIME

</div>

</div>


<div class="result-row">

<div class="result-label">

ACCESSED

</div>

<div class="result-value">

$RECORD

</div>

</div>


<div class="result-row">

<div class="result-label">

DOWNLOADED

</div>

<div class="result-value">

$DOWNLOAD

</div>

</div>


<div class="result-row">

<div class="result-label">

LOCAL FILE

</div>

<div class="result-value">

$LOCAL_STATUS

</div>

</div>


<div class="result-row">

<div class="result-label">

SURVIVING EVIDENCE

</div>

<div class="result-value">

$SURVIVING

</div>

</div>


<div class="result-row">

<div class="result-label">

EXAMINER

</div>

<div class="result-value">

$EXAMINER

</div>

</div>


<div class="conclusion">

CONCLUSION: Activity reconstructed

</div>


<div class="forensic-note">

This demonstration reconstructs controlled activity from
surviving ORION application/server evidence. It does not
break Tor anonymity or claim identification of a real person.

</div>


</div>

</div>


</main>

</div>

</body>

</html>
HTML

echo
echo "=============================================="
echo " ORION INVESTIGATOR READY"
echo "=============================================="
echo
echo "Usage:"
echo "~/orion_investigator.sh ORION-001 VISITOR-01"
echo
echo "Examiner: HARSHITHA"
echo "=============================================="
