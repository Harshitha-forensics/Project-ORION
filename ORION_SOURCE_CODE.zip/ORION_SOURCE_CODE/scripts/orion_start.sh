#!/bin/bash
echo "========================================"
echo "       ORION FORENSIC LAB START"
echo "========================================"

sudo systemctl start nginx
sudo systemctl start tor@default

echo
echo "NGINX: $(sudo systemctl is-active nginx)"
echo "TOR:   $(sudo systemctl is-active tor@default)"

echo
echo "NGINX CONFIG:"
sudo nginx -t

echo
echo "ORION ONION ADDRESS:"
sudo cat /var/lib/tor/orion/hostname

echo
echo "LOCAL WEB TEST:"
curl -I --max-time 10 http://127.0.0.1 2>/dev/null | head -n 1

echo
echo "========================================"
echo "             ORION READY"
echo "========================================"
