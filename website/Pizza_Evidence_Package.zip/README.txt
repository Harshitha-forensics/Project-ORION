PROJECT ORION
Educational Digital Forensics Demonstration

Purpose:
This package contains sample research records for demonstrating
digital evidence documentation and investigation workflows.

Topics:
1. Pizza and food research
2. Flowers and botanical research
3. Mountains and geography
4. Football and sports
5. Space and astronomy
6. Technology
7. Music
8. Photography
9. Travel
10. Artificial intelligence

Evidence note:
These are educational sample files, not evidence recovered
from a real person or real criminal investigation.

Investigator reminder:
Record evidence sources, timestamps, file hashes, and limitations.
A web-server access log can show requests, but does not by itself
prove that a file was saved or later deleted from a visitor's device.
